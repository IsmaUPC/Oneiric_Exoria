<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.2" name="collisions" tilewidth="32" tileheight="32" tilecount="2" columns="2">
 <image source="collisions.png" width="64" height="32"/>
</tileset>
